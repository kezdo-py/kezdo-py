##  привет👋, I'm Kezdo

<!--
**kezdo-py/kezdo-py** is a ✨ _special_ ✨ repository because its `README.md` (this file) appears on your GitHub profile.

Here are some ideas to get you started:

- 🔭 I’m currently working on ...
- 🌱 I’m currently learning ...
- 👯 I’m looking to collaborate on ...
- 🤔 I’m looking for help with ...
- 💬 Ask me about ...
- 📫 How to reach me: ...
- 😄 Pronouns: ...
- ⚡ Fun fact: ...
-->
- 😊 I'm like learning **Russian** language
- 🌱 I’m currently learning [**laravel**](https://laravel.com) framework
    👩‍💻🔥🔥🔥

![i'm bussy](https://media.giphy.com/media/v1.Y2lkPTc5MGI3NjExbWVxamJ2amhpZXE3ZWtrbG96cHUwcmJqanJvcnI1dG1mN2h1NWI1dSZlcD12MV9naWZzX3NlYXJjaCZjdD1n/3ohhwhQt5jKqjIU5Es/giphy.gif)

<div align="center">
  <img src="https://github-readme-stats.vercel.app/api?username=kezdo-py&hide_title=false&hide_rank=false&show_icons=true&include_all_commits=true&count_private=true&disable_animations=false&theme=dracula&locale=en&hide_border=false&order=1" height="150" alt="stats graph"  />
  <img src="https://github-readme-stats.vercel.app/api/top-langs?username=kezdo-py&locale=en&hide_title=false&layout=compact&card_width=320&langs_count=5&theme=dracula&hide_border=false&order=2" height="150" alt="languages graph"  />
</div>

###

<picture>
  <source media="(prefers-color-scheme: dark)" srcset="https://raw.githubusercontent.com/kezdo-py/kezdo-py/output/pacman-contribution-graph-dark.svg">
  <source media="(prefers-color-scheme: light)" srcset="https://raw.githubusercontent.com/kezdo-py/kezdo-py/output/pacman-contribution-graph.svg">
  <img alt="pacman contribution graph" src="https://raw.githubusercontent.com/kezdo-py/kezdo-py/output/pacman-contribution-graph.svg">
</picture>

###